<header>
    <h1>Médiatèque</h1>
    <nav>
        <ul class="nav justify-content-left">
            <li class="nav-item"><a class="nav-link" href="./index.php">Home</a></li>
            <?php 
            if(!$_SESSION["accesAdmin20200727"]){
                //var_dump($_COOKIE);
                ?>
                <li class="nav-item"><a class="nav-link" href="./back/connexion.php">Connexion</a></li>
                <?php
            }else{
                //var_dump($_COOKIE);
                ?>
                <li class="nav-item"><a class="nav-link" href="./back/index.php">Admin</a></li>
                <li class="nav-item"><a class="nav-link" href="./back/deconnexion.php">Déconnexion</a></li>
                <?php
            }
            ?>
        </ul>
    </nav>
</header>