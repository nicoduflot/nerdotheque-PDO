<link rel="stylesheet" href="../css/bootstrap.min.css" />
<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/bootstrap.min.js"></script>
<script src="../js/poppers.min.js"></script>