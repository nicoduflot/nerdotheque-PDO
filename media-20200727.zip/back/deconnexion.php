<?php
    session_start();
    include "../functions/functions.php";
    include "../functions/sql.php";
    session_destroy();
    destroyCookie();
    header("location: ../index.php");
?>